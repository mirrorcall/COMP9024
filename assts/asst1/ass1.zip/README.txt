README

	AUTOTEST is a bash based shell-script which allows you to
	run several autotest checking how your doubly linked list
	is going. It can be simply ran by ./autotest (or just
	autotest after setting down enviromental variable).

STRUCTURE

	autotest - running autotest script.  generator.py - python3
	script, determining the range of number as input to be
	sampling.  mem.output - checking how much memory was using,
	and determining whether there was a memory leak.

VCS
	To download all the files require: git clone